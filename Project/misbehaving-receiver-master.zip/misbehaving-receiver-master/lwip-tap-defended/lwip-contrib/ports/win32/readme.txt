lwIP for Win32

- MSVC6 compiler, read contrib\ports\win32\msvc6\readme.txt

- MSVC8 compiler, read contrib\ports\win32\msvc8\readme.txt

lwIP: http://savannah.nongnu.org/projects/lwip/
WinPCap: http://netgroup-serv.polito.it/winpcap/
Visual C++: http://www.microsoft.com/express/download/
