#ifndef __RTP_H__
#define __RTP_H__

#if LWIP_SOCKET && LWIP_IGMP
void rtp_init(void);
#endif /* LWIP_SOCKET && LWIP_IGMP */

#endif /* __RTP_H__ */
